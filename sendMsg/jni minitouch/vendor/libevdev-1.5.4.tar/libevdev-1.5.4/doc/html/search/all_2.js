var searchData=
[
  ['event_20handling',['Event handling',['../group__events.html',1,'']]],
  ['evdev_20ioctls',['evdev ioctls',['../ioctls.html',1,'']]]
];
