#include <libevdev/libevdev.h>
#include <libevdev/libevdev-uinput.h>

int main(void) {
	return 0;
}
